package main

import "fmt"

// The Abstract Factory pattern provides a way to create related objects without specifying their concrete classes.
// This is useful in situations where we want to create objects based on a certain theme or context.
// By using the Abstract Factory pattern, we can create these objects without specifying their concrete classes,
// which makes it easy to change the theme or context of our application.
// The abstract factory pattern decouples the client code from the concrete classes by providing an interface
// that creates objects. This means that the client code can be written to depend on the interface, rather than
// the concrete classes. This makes the code more flexible and easier to maintain
// In essence, we hide the implementation details for a given object from the end user, and can change them
// easily without breaking code that depends on the creation process.

// Animal is the type for our abstract factory. All concrete classes must implement all the listed
// methods in order to implement this interface. This is a way of enforcing constraints on created objects.
type Animal interface {
	Says()
	LikesWater() bool
}

// Dog is the concrete factory for Dogs.
type Dog struct{}

// Says is necessary for Dog to implement Animal.
func (d *Dog) Says() {
	// Here, we simply hard code the response. However, in the real world, we might call a database to
	// look info up, or go to some remote API to get the information.
	fmt.Println("Woof")
}

// LikesWater is necessary for Dog to implement Animal.
func (d *Dog) LikesWater() bool {
	// Here, we simply hard code the response. However, in the real world, we might call a database to
	// look info up, or go to some remote API to get the information. After all, some dogs like water,
	// and some dogs do not.
	return true
}

// Cat is the concrete factory for Cats.
type Cat struct{}

// Says is necessary for Cat to implement Animal.
func (c *Cat) Says() {
	fmt.Println("Meow")
}

// LikesWater is necessary for Cat to implement Animal.
func (c *Cat) LikesWater() bool {
	return false
}

// AnimalFactory is the interface we use to create an animal (Cat or Dog).
// We don't actually need this type, but it makes things more readable.
type AnimalFactory interface {
	New() Animal
}

// DogFactory is the concrete factory for Dogs. It implements AnimalFactory.
type DogFactory struct{}

// New allows DogFactory to implement AnimalFactory.
func (df *DogFactory) New() Animal {
	return &Dog{}
}

// CatFactory is the concrete factory for Dogs. It implements AnimalFactory.
type CatFactory struct{}

// New allows CatFactory to implement AnimalFactory.
func (cf *CatFactory) New() Animal {
	return &Cat{}
}

func main() {
	// Create one each of a DogFactory and a CatFactory variable.
	dogFactory := DogFactory{}
	catFactory := CatFactory{}

	// Call the New method to create a dog and a cat.
	dog := dogFactory.New()
	cat := catFactory.New()

	// These types are related (in the same family), but of different
	// concrete types.
	dog.Says()
	cat.Says()

	fmt.Println("A dog likes water:", dog.LikesWater())
	fmt.Println("A cat likes water", cat.LikesWater())
}
