module go-breeders

go 1.20

require (
	github.com/go-chi/chi/v5 v5.0.8 // indirect
	github.com/go-sql-driver/mysql v1.7.1 // indirect
	github.com/tsawler/toolbox v1.2.1 // indirect
)
